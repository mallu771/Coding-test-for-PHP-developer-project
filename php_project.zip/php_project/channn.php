<?php
error_reporting(0);
include "config.php";
$_SESSION["admin_Id"]="1";
$admin_Id;
$con = mysqli_connect('localhost','root','','comment') or die('Unable To connect');
if(count($_POST)>0) {
	$result = mysqli_query($con,"SELECT *from admin WHERE admin_Id='" . $_SESSION["admin_Id"]. "'");
    $row=mysqli_fetch_array($result);
if($_POST["currentPassword"] == $row["password"]) {
	mysqli_query($con,"UPDATE admin set password='".$_POST["newPassword"] ."'WHERE admin_Id='" .$_SESSION["admin_Id"]. "'");
	$message = "Password Changed Sucessfully";
}
 else
	$message = "Password is not correct";
	
}
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: login.php');
}
?>


<!DOCTYPE html>
<html>
<head>
<title>Password Change</title>
<script>
function validatePassword() {
var currentPassword,newPassword,confirmPassword,output = true;

currentPassword = document.frmChange.currentPassword;
newPassword = document.frmChange.newPassword;
confirmPassword = document.frmChange.confirmPassword;

if(!currentPassword.value) {
	currentPassword.focus();
	document.getElementById("currentPassword").innerHTML = "required";
	output = false;
}
else if(!newPassword.value) {
	newPassword.focus();
	document.getElementById("newPassword").innerHTML = "required";
	output = false;
}
else if(!confirmPassword.value) {
	confirmPassword.focus();
	document.getElementById("confirmPassword").innerHTML = "required";
	output = false;
}
if(newPassword.value != confirmPassword.value) {
	newPassword.value="";
	confirmPassword.value="";
	newPassword.focus();
	document.getElementById("confirmPassword").innerHTML = "not same";
	output = false;
} 	
return output;
}
</script>
</head>
<body style="color:blue; height:60%;
	width:45%;padding:10px;margin:70px auto;
	background-image: url('ma.jfif')">
	<div style="background:lightgreen;border:1px solid black;width:90%;height:350px">
<h3 align="center" style="background-color:blue;color:white">CHANGE PASSWORD</h3>
<div><?php if(isset($message)) { echo $message; } ?></div>
<form  method="post" action="" align="center" onSubmit="return validatePassword()">
Current Password:
<input type="password" name="currentPassword" placeholder="Current Password"><span id="currentPassword" class="required" ></span>
<br><br>
New Password:
<input type="password" name="newPassword" placeholder="New Password"><span id="newPassword" class="required"></span>
<br><br>
Confirm Password:
<input type="password" name="confirmPassword" placeholder="Confirm Password"><span id="confirmPassword" class="required"></span>
<br><br><br>
<input style="padding:5px;color:white;background-color:blue" type="submit">
<input style="padding:5px;color:white;background-color:blue"type="submit" value="Logout" name="but_logout" method='post' action='login.php'>
</form>
</div>
<br>
<br>
</body>
</html>



