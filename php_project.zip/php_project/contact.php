<?php 
include('dbconfig.php');
extract($_POST);
if(isset($save))
{

mysqli_query($conn,"insert into contact values('id','$n','$m','$e','$msg',now())");
	
$err="<font color='red'><h2>Admin Will Contact you soon</h2></font>";	

}

?>
	<?php
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: home.php');
}
?>
        
        <div class="container">

        <!-- Page Heading/Breadcrumbs -->
        <div class="row">
            <div class="col-lg-12">
                
                <ol class="breadcrumb">
                    
                    </li>
                   
                </ol>
            </div>
        </div>
        
       <div class="row">
            <div style="text-align:center;background-image: url('mg.jfif')" class="floatLeft">
                <h1 style="font-size:200%"><font color="red">Contact us </font></h1>
                <form style="height:400px;width:400px;background:lightblue;margin:auto;border:2px solid black"name="sentMessage" method="post" id="contactForm" novalidate>
                  <?php echo @$err; ?>
				    <div class="control-group form-group">
                        
						
						<div class="controls"></br>
                            <label>Name:</label>
                            <input style="padding:5px;width:250px" type="text" class="form-control" name="n" required data-validation-required-message="Please enter your name.">
                            <p class="help-block"></p>
                        </div>
                    </div>
                    <div class="control-group form-group"></br>
                        <div class="controls">
                            <label>Mobile Number:</label>
                            <input style="padding:5px;width:250px"  type="tel"  pattern="[0-9]{10}" class="form-control" name="m" required data-validation-required-message="Please enter your phone number.">
                        </div>
                    </div>
                    <div class="control-group form-group"></br>
                        <div class="controls">
                            <label>Email Address:</label>
                            <input style="padding:5px;width:250px"  type="email" class="form-control" name="e" required data-validation-required-message="Please enter your email address.">
                        </div>
                    </div>
					
					
                    <tr class="control-group form-group"></br>
                        <td class="controls">
                            <label>Message:</label>
							</td>
							<td>
                            <textarea style="padding:5px;width:250px"  rows="10" name="msg" cols="70" class="form-control" id="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
                        </td>
                    </tr></br></br>
					
                    <div id="success"></div>
                    <!-- For success/fail messages -->
                    <button style="padding:5px;background:blue;color:white" type="submit" name="save" class="btn btn-primary">Send Message</button>
					<button style="padding:5px;background:blue;color:white" type="logout" name="but_logout" class="btn btn-primary" action="login.php" method="post">Logout</button>
					
                </form>
			</div>
		    </div>
        </div>
        </div>
        
      
