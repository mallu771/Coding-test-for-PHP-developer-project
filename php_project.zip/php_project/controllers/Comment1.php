<?php 
	include_once './database/DB.php';
	class Comment1
	{
		private $db;
		
		private $username;
		private $email;
		private $password;
	
		private $table = "users1";

		public function __construct()
		{
			$this->db = new DB();
		}

		public function setData($username,$email,$password)
		{
			$this->username= $username;
			$this->email=$email;
			$this->password=$password;
		
		}
		
		public function create()
		{
			$query = "INSERT INTO $this->table(username,email,password,usn,create_datetime) VALUES('$this->username','$this->email','$this->password','$this->usn', now())";
			$insert_comment = $this->db->insert($query);
			return $insert_comment;
		}

		public function index()
		{
			$query = "SELECT * FROM $this->table ORDER BY id DESC";
			$result = $this->db->select($query);
			return $result;
		}

		public function dateFormat($data)
		{
			date_default_timezone_set('Asia/Dhaka');
			$date = date('M j, h:i:s a', time());
			return $date;
		}
	}
 ?>