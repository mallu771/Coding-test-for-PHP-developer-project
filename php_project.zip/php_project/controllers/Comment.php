<?php 
	include_once './database/DB.php';
	class Comment
	{
		private $db;
		private $name;
		private $email;
		private $mobile_no;
		private $usn;
		private $address;
	
		private $comment;
		private $table = "tbl_comments";

		public function __construct()
		{
			$this->db = new DB();
		}

		public function setData($name,$email_id,$mobile_no,$usn,$address,$comment)
		{
			$this->name= $name;
			$this->email_id=$email_id;
			$this->mobile_no=$mobile_no;
			$this->usn=$usn;
			$this->address=$address;
			
			$this->comment = $comment;
		}

		public function create()
		{
			$query = "INSERT INTO $this->table(name,email_id,mobile_no,usn,address,comment, comment_time) VALUES('$this->name','$this->email_id','$this->mobile_no','$this->usn','$this->address','$this->comment', now())";
			$insert_comment = $this->db->insert($query);
			return $insert_comment;
		}

		public function index()
		{
			$query = "SELECT * FROM $this->table ORDER BY id DESC";
			$result = $this->db->select($query);
			return $result;
		}
		
		public function dateFormat($data)
		{
			date_default_timezone_set('Asia/Dhaka');
			$date = date('M j, h:i:s a', time());
			return $date;
		}
	}
 ?>