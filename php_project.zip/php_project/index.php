<?php 
	include_once 'controllers/Comment.php';
	$com = new Comment();
	
	
 ?>
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>
<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="utf-8">
 	<title>USER COMMENTS</title>
 	<style>
 		.box{border: 6px solid #999;margin: 30px auto 0;padding: 20px;width: 1000px;height: 250px;overflow: scroll;}
 		.box ul{margin: 0;padding: 0;list-style: none;}
 		.box li{display: block;border-bottom: 1px dashed #ddd;margin-bottom: 5px;padding-bottom: 5px;}
 		.box li:last-child{border-bottom: 0 dashed #ddd;}
 		.box span{color: #888;}
		#left{color:red; text-align:center;}
 	</style>
 </head>
 <body style=" background-color:lightgreen;">
    <h1 id="left">USER COMMENTS</h1>
 	<div class="box">
 		<ul>
 			<?php 
 				$result = $com->index();
 				while ($data = $result->fetch_assoc()) {
 			 ?>
 			<li><b>id-><?php echo $data['id']; ?><b>-<?php echo $data['name']; ?> - <?php echo $data['email_id']; ?> - <?php echo $data['mobile_no'] ?> - <?php echo $data['usn'] ?> -<?php echo $data['address'] ?> -<?php echo $data['comment'] ?> - <?php echo $com->dateFormat($data['comment_time']); ?></li>
 			<?php } ?>
 		</ul>
 	</div><br><br>
 	<center>
 		<?php 
 			if (isset($_GET['msg'])) {
 				$msg = $_GET['msg'];
 				echo "<span style='color:red;font-size:20px'>".$msg."</span>";
	
				
			}
 		 ?>
		 
	
	<?php
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: login.php');
}
?>
	<form action="post_comment.php" method="post"><br><br><br>
 		<table>
		
 			<tr>
 				<td>Your Name:<span style= color:red;>*</span></td>
 				<td><input style="width: 230px;height: 30px;" type="" name="name" placeholder="Please enter your name"></td>
 			</tr>
			<tr>
 				<td>Email_id:<span style= color:red;>*</span></td>
 				<td><input style="width: 230px;height: 30px;" type="text" name="email_id" placeholder="Please enter your email_id"></td>
 			</tr>
			<tr>
 				<td>Mobile No:<span style= color:red;>*</span></td>
 				<td><input style="width: 230px;height: 30px;" type="tel" name="mobile_no" pattern="[0-9]{10}" placeholder="Please enter your mobile_no"></td>
 			</tr>
			<tr>
 				<td>USN:</td>
 				<td><input style="width: 230px;height: 30px;" type="text" name="usn" placeholder="Please enter your usn"></td>
 			</tr>
			<tr>
 				<td>Address:<span style= color:red;>*</span></td>
 				<td><input style="width: 230px;height: 30px;" type="text" name="address" placeholder="Please enter your address"></td>
 			</tr>
				
 			<tr>
 				<td>Comment:<span style= color:red;>*</span></td>
 				<td>
 					<textarea name="comment" rows="7" cols="30" placeholder="Please enter your comment"></textarea>
 				</td>
 			</tr></br>
 			<tr>
 				<td></td>
 				<td><input style="padding:5px;color:white;background-color:blue"  type="submit" name="submit" value="Post" ></td>
				<td><input style="padding:5px;color:white;background-color:blue" type="Reset" value="Reset"></td>
				<td><input style="padding:5px;color:white;background-color:blue"type="submit" value="Logout" name="but_logout" method='post' action='login.php'></td>
				<td><p style="padding:5px;background-color:blue"><a style="color:white" href="contact.php">Contact_admin</a></p>
 			</tr>
 		</table>
 	</form>
 	<center>
 </body>
 </html>
 