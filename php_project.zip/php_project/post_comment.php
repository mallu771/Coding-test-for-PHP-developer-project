<?php 
	include_once 'controllers/Comment.php';
	$com = new Comment();
	if (isset($_POST['submit'])) {
	
		$name    = $_POST['name'];
		$email_id=$_POST['email_id'];
		$mobile_no=$_POST['mobile_no'];
		$usn=$_POST['usn'];
		$address=$_POST['address'];
		
		$comment = $_POST['comment'];
		
	
	

		if (empty($name) || empty($email_id) || empty($mobile_no) || empty($usn) ||empty($address)||empty($comment)) {
			echo "<span style='color:blue; font-size:20px'>Field must not be empty !(thank you)</span>";
		} else {
			$com->setData($name,$email_id,$mobile_no,$usn,$address,$comment);
			if ($com->create()) {
				header('Location: index.php?msg='.urlencode('Comment Posting Successfully'));
			}
		}
	}
		if (isset($_POST['but_logout'])) {
		
				session_destroy();
				header('Location: home.php');
			}
		
 ?>