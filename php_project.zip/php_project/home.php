 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comment";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>project</title>
	<link rel="stylesheet" href="hw1.css">
</head>
<body>
	<header style="background-color:lightblue">


		<h1>PHP PROJECT</h1>
		<nav style="font-size:100%">
			<a href="login.php" class = "active">Admin Login</a>
			<a href="login1.php">User login</a>
			<a href="contact.php">Admin_Contact</a>
			
		</nav>
	</header>
		<main>
			<aside class = "center ">
			<a href="sammu.jpg"><img class="image responsive image-resize" src="aa.jfif"/> </a>

			<img class="image responsive image-resize"  src="ma.jfif"/></a>


			<a href="kk.jpg"><img class="image responsive image-resize" src="kk.jpg"></a>
		</aside>
			<section class = "right">
			<h2 style="font-size:250%;color:red">READ USERS</h2>
            <p style="font-size:200%">1 .user registration.
Registration fields
	-email
	-phone
	-password
	-confirm password</p>
	<p style="font-size:200%">
2. Registered user can create, read and update their profile
Profile fields
	-First name
-Last Name
-role (editor/writer)
</p>
<p style="font-size:200%">
3. User with writer role can create posts and read, update and delete only their posts
Article fields
	-title
	-post
	</p>
	<p style="font-size:200%">
4. User with writer role can read comments on his posts.
</p>
<p style="font-size:200%">
5. User with editor role can read all posts and comment on posts.
</p>
</section>
</main>
</body>
</html>