
<?php

// php code to Delete data from mysql database 

if(isset($_POST['delete']))
{
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "comment";
    
    // get id to delete
    $id = $_POST['name'];
    
    // connect to mysql
    $connect = mysqli_connect($hostname, $username, $password, $databaseName);
    
    // mysql delete query 
    $query = "DELETE FROM `` WHERE `name` = $name";
    
    $result = mysqli_query($connect, $query);
    
    if($result)
    {
        echo 'comment Deleted';
    }else{
        echo 'comment Not Deleted';
    }
    mysqli_close($connect);
}

?>


<!DOCTYPE html>

<html>

    <head>

        <title> </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>

        <form action="" method="post">

            NAME TO DELETE:&nbsp;<input type="text" name="name"><br><br>

            <input style="padding:5px;color:white;background-color:blue" type="submit" name="delete" value="Clear Data">

        </form>

    </body>
</html>