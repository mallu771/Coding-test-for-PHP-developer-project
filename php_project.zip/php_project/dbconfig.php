<?php
$conn=mysqli_connect("localhost","root","","comment")or die(mysqli_error());
?>
