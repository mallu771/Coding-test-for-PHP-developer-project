<?php
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: login.php');
}
?>
<?php 
	include_once 'controllers/Comment1.php';
	$com = new Comment1();
	
	
 ?>


<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="utf-8">
 	<title>Comment System</title>
 	<style>
 		.box{border: 6px solid #988;margin: 20px auto 0;padding: 20px;width: 800px;height: 250px;overflow: scroll;background-color:#969;}
 		.box ul{margin: 0;padding: 0;list-style: none;}
 		.box li{display: block;border-bottom: 1px dashed #ddd;margin-bottom: 5px;padding-bottom: 5px;}
 		.box li:last-child{border-bottom: 0 dashed #ddd;}
 		.box span{color: #888;}
	
 	</style>
 </head>
 <body style="background-image: url('nn.jpg')">
  
 	<div class="box">
 		<ul>
 			<?php 
 				$result = $com->index();
 				while ($data = $result->fetch_assoc()) {
 			 ?>
 			<li><b>id-><?php echo $data['id']; ?><b>-<?php echo $data['username']; ?> - <?php echo $data['email']; ?>  -<?php echo $data['password'] ?> - <?php echo $com->dateFormat($data['create_datetime']); ?></li>
 			<?php } ?>
 		</ul>
 	</div><br><br>
 	<center>
 		<?php 
 			if (isset($_GET['msg'])) {
 				$msg = $_GET['msg'];
 				echo "<span style='color:red;font-size:20px'>".$msg."</span>";
	
				
			}
 		 ?>
		 
	
	<?php



if(isset($_POST['delete']))
{
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "comment";
    
    // get id to delete
    $id = $_POST['id'];
    
    // connect to mysql
    $connect = mysqli_connect($hostname, $username, $password, $databaseName);
    
    // mysql delete query 
    $query = "DELETE FROM `users1` WHERE `id` = $id";
    
    $result = mysqli_query($connect, $query);
    
    if($result)
    {
        echo 'Data Deleted';
    }else{
        echo 'Data Not Deleted';
    }
    mysqli_close($connect);
}

?>

<!DOCTYPE html>

<html>

    <head>

        <title> </title>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>

    <body>

        <form action="" method="post" style="text-align:center;width:400px;height:150px;margin:30px auto;padding:7px;border-radius:5px;background-color:#556;border:2px solid #899">

           <p style="color:red"> ID TO DELETE:&nbsp<input type="text" name="id" placeholder="user_id delete"><br><br></p>

            <input style="padding:5px;color:white;background-color:blue" type="submit" name="delete" value="Clear Data">
<input style="padding:5px;color:white;background-color:blue"type="submit" value="Logout" name="but_logout" method='post' action='login.php'>
        </form>

    </body>

</html>
