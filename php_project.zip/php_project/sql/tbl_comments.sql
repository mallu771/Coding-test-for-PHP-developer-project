

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";



CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
   `email_id` varchar(50) NOT NULL,
   `mobile_no` varchar(10) NOT NULL,
   `usn` varchar(11) NOT NULL,
   `address` varchar(100) NOT NULL,
  
  `comment` text NOT NULL,
  `comment_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `tbl_comments` (`id`, `name`,`email_id`,`mobile_no`,`usn`,`address`, `comment`, `comment_time`) VALUES
(1, 'vijay','mallikarjunbajantri891@gmail.com','9164026234','2kd17cs030','a\p:katageri dist:belagvi','good sir\r\n', '2017-03-01 23:37:09'),
(2, 'vishal','mallub1233@gmail.com','9164026235','2kd17cs030','a\p:badachi dist:belagvi','hi bro', '2017-03-01 23:39:02'),
(3, 'klecet', 'mallikarjungopalbajantri1999@gmail.com','9164026236','2kd17cs031','a\p:nandagav dist:belagvi','what are you doing? ', '2017-03-01 23:40:12'),
(4, 'manju', 'bajantri1999@gmail.com','9164026237','2kd17cs032','a\p:burltti dist:belagvi','Hello', '2017-03-01 23:51:31'),
(5, 'mallu', 'katageri1999@gmail.com','9164026238','2kd17cs033','a\p:kokatnor dist:belagvi','Hi', '2017-03-01 23:32:46');


ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
