CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `n` varchar(100) NOT NULL,
  `m` int(10) NOT NULL,
  `e` varchar(100) NOT NULL,
   `msg` varchar(100) NOT NULL,
  `create_datetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
);

