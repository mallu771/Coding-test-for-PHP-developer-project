

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_Id` int(8) NOT NULL AUTO_INCREMENT,
  `userName` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL,
  `displayName` varchar(55) NOT NULL,
  PRIMARY KEY (`admin_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;



INSERT INTO `admin` (`admin_Id`, `userName`, `password`, `displayName`) VALUES
(1, 'abc',  '12345','mallikarjun'),
(2, 'xyz', 'manju123','raju'),
(3, 'kle',  '12345','ravi'),
(4, 'cet', '12345','ramesh'),
(5, 'katageri','klecet123','praveen');

