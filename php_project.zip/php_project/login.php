<?php

include "config.php";

if(isset($_POST['but_submit'])){

    $uname = mysqli_real_escape_string($con,$_POST['txt_uname']);
    $password = mysqli_real_escape_string($con,$_POST['txt_pwd']);


    if ($uname != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from admin where username='".$uname."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['uname'] = $uname;
            header('Location: nav.html');
        }else{
            echo "<span style='color:red;font-size:30px'>Invalid username and password</span>";
        }

    }
}
?>
<?php
if(isset($_POST['but_logout'])){
    session_destroy();
    header('Location: home.php');
}
?>
<html>
    <head>
        <title>Admin_login_page</title>
        <link href="css/style.css" rel="stylesheet" type="text/css">
    </head>
    <body style="background-image: url('pp.jpg');margin:70px auto">
        <div class="container">
            <form method="post" action="">
                <div id="div_login" style="background-color:cornflowerblue;width:600px;height:400px">
                    <h1> Admin Login</h1>
						
                    <div>
                        <input type="text" class="textbox" id="txt_uname" name="txt_uname" placeholder="Username" />
                    </div>
                    <div>
                        <input type="password" class="textbox" id="txt_uname" name="txt_pwd" placeholder="Password"/>
                    </div>
                    <div>
                        <input type="submit" value="Submit" name="but_submit" id="but_submit" />
                    
                   <input style="padding: 5px;width: 120px;background-color: lightseagreen;border: 0px; color: white;" type="submit" value="Reset" id="but_submit" />
				    <input style="text-align:center;padding:7px;font-size:15px;color:white;background-color:lightseagreen;width:100px"  type="submit" value="Logout" name="but_logout" class="logout-button"/>
				 <a style="text-align:right;padding:2px;font-size:20px;color:white;background-color:lightseagreen" href="channn.php">change_Password?</a>
				  
				  
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>

